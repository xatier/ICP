// Name and Student ID

#include <stdio.h>






int main(void)
{
	printf("%d\n",common(123454321,13575));
	printf("%d\n",common(56789,1234));
	printf("%d\n",common(2010,0));
	printf("%d\n",common(-56789,-12345));
	printf("%d\n",common(-2147483648,2147483647));
}
