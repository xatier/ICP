// Name and Student ID

#include <stdio.h>






int main(void)
{
	printf("Enter an integer <= 10: ");
	int n;
	while (scanf("%d",&n)!=EOF) {
		printf("There are %d subsets.\n\n",p(n));
		printf("Enter an integer <= 10: ");
	}
}
