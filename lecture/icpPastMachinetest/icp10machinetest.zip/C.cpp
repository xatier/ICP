#include <stdio.h>





int main(void) 
{ 
	printf("\n%d quaternary strings in total\n\n",even(1));
	printf("\n%d quaternary strings in total\n\n",even(2));
	printf("\n%d quaternary strings in total\n\n",even(3));
	printf("\n%d quaternary strings in total\n\n",even(4));
}
 