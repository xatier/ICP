#include <stdio.h>
#include <limits.h>





int main(void)
{
	goodsequence(23232);
	goodsequence(1234567890);
	goodsequence(1093500000);
	goodsequence(3456565657u);
	goodsequence(3333333333u);
}